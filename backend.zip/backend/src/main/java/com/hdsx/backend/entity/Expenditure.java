package com.hdsx.backend.entity;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.io.Serializable;

/**
 * (Expenditure)表实体类
 *
 * @author makejava
 * @since 2023-08-01 11:47:54
 */
@SuppressWarnings("serial")
public class Expenditure extends Model<Expenditure> {
    //使用编号
    @TableId
    private Long expenditureId;
    //所属单位的编号
    private Long unitId;
    //使用日期
    private Date expenditureDate;
    //使用金额
    private Double expenditureAmount;
    //操作人员
    private String expenditureUser;


    public Long getExpenditureId() {
        return expenditureId;
    }

    public void setExpenditureId(Long expenditureId) {
        this.expenditureId = expenditureId;
    }

    public Long getUnitId() {
        return unitId;
    }

    public void setUnitId(Long unitId) {
        this.unitId = unitId;
    }

    public Date getExpenditureDate() {
        return expenditureDate;
    }

    public void setExpenditureDate(Date expenditureDate) {
        this.expenditureDate = expenditureDate;
    }

    public Double getExpenditureAmount() {
        return expenditureAmount;
    }

    public void setExpenditureAmount(Double expenditureAmount) {
        this.expenditureAmount = expenditureAmount;
    }

    public String getExpenditureUser() {
        return expenditureUser;
    }

    public void setExpenditureUser(String expenditureUser) {
        this.expenditureUser = expenditureUser;
    }

    /**
     * 获取主键值
     *
     * @return 主键值
     */
    @Override
    protected Serializable pkVal() {
        return this.expenditureId;
    }
}

