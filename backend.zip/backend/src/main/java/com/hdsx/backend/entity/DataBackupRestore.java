package com.hdsx.backend.entity;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.io.Serializable;

/**
 * (DataBackupRestore)表实体类
 *
 * @author makejava
 * @since 2023-08-01 11:47:54
 */
@SuppressWarnings("serial")
public class DataBackupRestore extends Model<DataBackupRestore> {
    //备份编号
    @TableId
    private Long backupId;
    //备份名称
    private String backupName;
    //备份日期
    private Date backupDate;
    //备份文件路径
    private String backupFilePath;


    public Long getBackupId() {
        return backupId;
    }

    public void setBackupId(Long backupId) {
        this.backupId = backupId;
    }

    public String getBackupName() {
        return backupName;
    }

    public void setBackupName(String backupName) {
        this.backupName = backupName;
    }

    public Date getBackupDate() {
        return backupDate;
    }

    public void setBackupDate(Date backupDate) {
        this.backupDate = backupDate;
    }

    public String getBackupFilePath() {
        return backupFilePath;
    }

    public void setBackupFilePath(String backupFilePath) {
        this.backupFilePath = backupFilePath;
    }

    /**
     * 获取主键值
     *
     * @return 主键值
     */
    @Override
    protected Serializable pkVal() {
        return this.backupId;
    }
}

