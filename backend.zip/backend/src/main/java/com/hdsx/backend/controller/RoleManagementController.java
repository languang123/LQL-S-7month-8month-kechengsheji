package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.RoleManagement;
import com.hdsx.backend.service.RoleManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * (RoleManagement)表控制层
 *
 * @author makejava
 * @since 2023-08-01 11:47:56
 */
@RestController
@RequestMapping("/api/role-management")
public class RoleManagementController {

    @Autowired
    private RoleManagementService roleManagementService;

    @GetMapping("/list")
    public R<List<RoleManagement>> getAllRoleManagements(RoleManagement roleManagement) {
        List<RoleManagement> roleManagements = roleManagementService.list(new QueryWrapper<>(roleManagement));
        return R.ok(roleManagements);
    }

    @GetMapping("/list-paged")
    public R<Page<RoleManagement>> getPagedRoleManagements(@RequestParam(defaultValue = "1") long current,
                                                           @RequestParam(defaultValue = "10") long size,
                                                           RoleManagement roleManagement) {
        Page<RoleManagement> page = new Page<>(current, size);
        roleManagementService.page(page, new QueryWrapper<>(roleManagement));
        return R.ok(page);
    }

    @GetMapping("/get/{id}")
    public R<RoleManagement> getRoleManagementById(@PathVariable Serializable id) {
        return R.ok(roleManagementService.getById(id));
    }

    @PostMapping("/add")
    public R<String> addRoleManagement(@RequestBody RoleManagement roleManagement) {
        boolean success = roleManagementService.save(roleManagement);
        return success ? R.ok("Role management added successfully") : R.failed("Failed to add role management");
    }

    @PostMapping("/edit")
    public R<String> editRoleManagement(@RequestBody RoleManagement roleManagement) {
        boolean success = roleManagementService.updateById(roleManagement);
        return success ? R.ok("Role management edited successfully") : R.failed("Failed to edit role management");
    }

    @DeleteMapping("/delete/{roleId}")
    public R<?> deleteRoleManagements(@PathVariable Long roleId) {
        boolean success = roleManagementService.removeById(roleId);
        return success ? R.ok("Role managements deleted successfully") : R.failed("Failed to delete role managements");
    }

}

