package com.hdsx.backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hdsx.backend.dao.OperationLogDao;
import com.hdsx.backend.entity.OperationLog;
import com.hdsx.backend.service.OperationLogService;
import org.springframework.stereotype.Service;

/**
 * (OperationLog)表服务实现类
 *
 * @author makejava
 * @since 2023-08-01 11:47:55
 */
@Service("operationLogService")
public class OperationLogServiceImpl extends ServiceImpl<OperationLogDao, OperationLog> implements OperationLogService {

}

