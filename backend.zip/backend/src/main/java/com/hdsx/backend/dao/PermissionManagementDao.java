package com.hdsx.backend.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hdsx.backend.entity.PermissionManagement;
import org.apache.ibatis.annotations.Mapper;

/**
 * (PermissionManagement)表数据库访问层
 *
 * @author makejava
 * @since 2023-08-01 11:47:55
 */
@Mapper
public interface PermissionManagementDao extends BaseMapper<PermissionManagement> {

}

