package com.hdsx.backend.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.hdsx.backend.entity.UnitEmployee;

import java.util.List;

/**
 * (UnitEmployee)表服务接口
 *
 * @author makejava
 * @since 2023-08-06 14:39:16
 */
public interface UnitEmployeeService extends IService<UnitEmployee> {

}

