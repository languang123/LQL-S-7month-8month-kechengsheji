package com.hdsx.backend.entity;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.io.Serializable;

/**
 * (InsurancePayment)表实体类
 *
 * @author makejava
 * @since 2023-08-01 11:47:55
 */
@SuppressWarnings("serial")
public class InsurancePayment extends Model<InsurancePayment> {
    //缴纳编号
    @TableId
    private Long paymentId;
    //所属单位的编号
    private Long unitId;
    //缴纳日期
    private Date paymentDate;
    //缴纳金额
    private Double paymentAmount;
    //缴纳方式
    private String paymentMethod;
    //缴纳状态
    private String paymentStatus;


    public Long getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }

    public Long getUnitId() {
        return unitId;
    }

    public void setUnitId(Long unitId) {
        this.unitId = unitId;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public Double getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(Double paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    /**
     * 获取主键值
     *
     * @return 主键值
     */
    @Override
    protected Serializable pkVal() {
        return this.paymentId;
    }
}

