package com.hdsx.backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hdsx.backend.dao.ReductionWaiverDao;
import com.hdsx.backend.entity.ReductionWaiver;
import com.hdsx.backend.service.ReductionWaiverService;
import org.springframework.stereotype.Service;

/**
 * (ReductionWaiver)表服务实现类
 *
 * @author makejava
 * @since 2023-08-06 14:41:47
 */
@Service("reductionWaiverService")
public class ReductionWaiverServiceImpl extends ServiceImpl<ReductionWaiverDao, ReductionWaiver> implements ReductionWaiverService {

}

