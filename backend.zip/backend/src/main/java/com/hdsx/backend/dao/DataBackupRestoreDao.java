package com.hdsx.backend.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hdsx.backend.entity.DataBackupRestore;
import org.apache.ibatis.annotations.Mapper;

/**
 * (DataBackupRestore)表数据库访问层
 *
 * @author makejava
 * @since 2023-08-01 11:47:54
 */
@Mapper
public interface DataBackupRestoreDao extends BaseMapper<DataBackupRestore> {

}

