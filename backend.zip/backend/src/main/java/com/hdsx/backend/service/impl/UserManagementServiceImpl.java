package com.hdsx.backend.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hdsx.backend.dao.UserManagementDao;
import com.hdsx.backend.entity.UserManagement;
import com.hdsx.backend.service.UserManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * (UserManagement)表服务实现类
 *
 * @author makejava
 * @since 2023-08-01 11:47:57
 */
@Service("userManagementService")
public class UserManagementServiceImpl extends ServiceImpl<UserManagementDao, UserManagement> implements UserManagementService {
    UserManagementDao userManagementDao;

    @Autowired
    public UserManagementServiceImpl(UserManagementDao userManagementDao) {
        this.userManagementDao = userManagementDao;
    }
    @Override
    public UserManagement findByUsernameAndPassword(String username,String password) {
        QueryWrapper<UserManagement> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username", username).eq("password", password);

        return userManagementDao.selectOne(queryWrapper);
    }
}
