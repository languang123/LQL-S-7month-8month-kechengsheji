package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.InsurancePayment;
import com.hdsx.backend.service.InsurancePaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * (InsurancePayment)表控制层
 *
 * @author makejava
 * @since 2023-08-01 11:47:55
 */
//单位保障金缴纳信息管理
@RestController
@RequestMapping("/api/insurance-payment")
public class InsurancePaymentController {

    @Autowired
    private InsurancePaymentService insurancePaymentService;

    @PostMapping("/add")
    public R<String> addInsurancePayment(@RequestBody InsurancePayment insurancePayment) {
        boolean success = insurancePaymentService.save(insurancePayment);
        return success ? R.ok("Insurance payment added successfully") : R.failed("Failed to add insurance payment");
    }

    @PostMapping("/edit")
    public R<String> editInsurancePayment(@RequestBody InsurancePayment insurancePayment) {
        boolean success = insurancePaymentService.updateById(insurancePayment);
        return success ? R.ok("Insurance payment edited successfully") : R.failed("Failed to edit insurance payment");
    }

    @DeleteMapping("/delete/{paymentId}")
    public R<String> deleteInsurancePayment(@PathVariable Long paymentId) {
        boolean success = insurancePaymentService.removeById(paymentId);
        return success ? R.ok("Insurance payment deleted successfully") : R.failed("Failed to delete insurance payment");
    }

    @GetMapping("/get/{paymentId}")
    public R<InsurancePayment> getInsurancePayment(@PathVariable Long paymentId) {
        InsurancePayment payment = insurancePaymentService.getById(paymentId);
        return payment != null ? R.ok(payment) : R.failed("Insurance payment not found");
    }

    @GetMapping("/list")
    public R<List<InsurancePayment>> getAllInsurancePayments() {
        List<InsurancePayment> payments = insurancePaymentService.list();
        return R.ok(payments);
    }

    @GetMapping("/list-paged")
    public R<Page<InsurancePayment>> getPagedInsurancePayments(@RequestParam(defaultValue = "1") long current,
                                                               @RequestParam(defaultValue = "10") long size) {
        Page<InsurancePayment> page = new Page<>(current, size);
        Page<InsurancePayment> resultPage = insurancePaymentService.page(page);
        return R.ok(resultPage);
    }
}
