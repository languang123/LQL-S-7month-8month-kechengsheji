package com.hdsx.backend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hdsx.backend.entity.UnitType;

/**
 * (UnitType)表服务接口
 *
 * @author makejava
 * @since 2023-08-01 11:47:56
 */
public interface UnitTypeService extends IService<UnitType> {

}

