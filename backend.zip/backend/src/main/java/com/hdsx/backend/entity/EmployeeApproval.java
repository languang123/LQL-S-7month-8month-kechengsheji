package com.hdsx.backend.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.io.Serializable;

/**
 * (EmployeeApproval)表实体类
 *
 * @author makejava
 * @since 2023-08-01 11:47:54
 */
@SuppressWarnings("serial")
public class EmployeeApproval extends Model<EmployeeApproval> {
    //审核编号
    @TableId
    private Long approvalId;
    //所属单位的编号
    private Long unitId;
    //员工编号
    private Long employeeId;
    //审核状态
    private String approvalStatus;
    //审核意见
    private String approvalComments;


    public Long getApprovalId() {
        return approvalId;
    }

    public void setApprovalId(Long approvalId) {
        this.approvalId = approvalId;
    }

    public Long getUnitId() {
        return unitId;
    }

    public void setUnitId(Long unitId) {
        this.unitId = unitId;
    }

    public Long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }

    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public String getApprovalComments() {
        return approvalComments;
    }

    public void setApprovalComments(String approvalComments) {
        this.approvalComments = approvalComments;
    }

    /**
     * 获取主键值
     *
     * @return 主键值
     */
    @Override
    protected Serializable pkVal() {
        return this.approvalId;
    }
}

