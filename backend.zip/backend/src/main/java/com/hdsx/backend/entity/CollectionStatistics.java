package com.hdsx.backend.entity;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.io.Serializable;

/**
 * (CollectionStatistics)表实体类
 *
 * @author makejava
 * @since 2023-08-01 11:47:54
 */
@SuppressWarnings("serial")
public class CollectionStatistics extends Model<CollectionStatistics> {
    //统计编号
    @TableId
    private Long statisticId;
    //统计日期
    private Date statisticDate;
    //总征收金额
    private Double totalCollection;
    //总使用金额
    private Double totalExpenditure;
    //余额
    private Double totalBalance;


    public Long getStatisticId() {
        return statisticId;
    }

    public void setStatisticId(Long statisticId) {
        this.statisticId = statisticId;
    }

    public Date getStatisticDate() {
        return statisticDate;
    }

    public void setStatisticDate(Date statisticDate) {
        this.statisticDate = statisticDate;
    }

    public Double getTotalCollection() {
        return totalCollection;
    }

    public void setTotalCollection(Double totalCollection) {
        this.totalCollection = totalCollection;
    }

    public Double getTotalExpenditure() {
        return totalExpenditure;
    }

    public void setTotalExpenditure(Double totalExpenditure) {
        this.totalExpenditure = totalExpenditure;
    }

    public Double getTotalBalance() {
        return totalBalance;
    }

    public void setTotalBalance(Double totalBalance) {
        this.totalBalance = totalBalance;
    }

    /**
     * 获取主键值
     *
     * @return 主键值
     */
    @Override
    protected Serializable pkVal() {
        return this.statisticId;
    }
}

