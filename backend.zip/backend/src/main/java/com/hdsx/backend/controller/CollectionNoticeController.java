package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.CollectionNotice;
import com.hdsx.backend.service.CollectionNoticeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;
import java.util.List;

/**
 * (CollectionNotice)表控制层
 *
 * @author makejava
 * @since 2023-08-01 11:47:53
 */
@RestController
@RequestMapping("/api/collection-notice")
public class CollectionNoticeController {

    @Autowired
    private CollectionNoticeService collectionNoticeService;

    @GetMapping("/list")
    public R<List<CollectionNotice>> getAllCollectionNotices(CollectionNotice collectionNotice) {
        List<CollectionNotice> collectionNotices = collectionNoticeService.list(new QueryWrapper<>(collectionNotice));
        return R.ok(collectionNotices);
    }

    @GetMapping("/list-paged")
    public R<Page<CollectionNotice>> getPagedCollectionNotices(@RequestParam(defaultValue = "1") long current,
                                                               @RequestParam(defaultValue = "10") long size,
                                                               CollectionNotice collectionNotice) {
        Page<CollectionNotice> page = new Page<>(current, size);
        collectionNoticeService.page(page, new QueryWrapper<>(collectionNotice));
        return R.ok(page);
    }

    @GetMapping("/get/{id}")
    public R<CollectionNotice> getCollectionNoticeById(@PathVariable Serializable id) {
        return R.ok(collectionNoticeService.getById(id));
    }

    @PostMapping("/add")
    public R<String> addCollectionNotice(@RequestBody CollectionNotice collectionNotice) {
        boolean success = collectionNoticeService.save(collectionNotice);
        return success ? R.ok("Collection notice added successfully") : R.failed("Failed to add collection notice");
    }

    @PostMapping("/edit")
    public R<String> editCollectionNotice(@RequestBody CollectionNotice collectionNotice) {
        boolean success = collectionNoticeService.updateById(collectionNotice);
        return success ? R.ok("Collection notice edited successfully") : R.failed("Failed to edit collection notice");
    }

    @DeleteMapping("/delete/{noticeId}")
    public R<?> deleteCollectionNotices(@PathVariable Long noticeId) {
        boolean success = collectionNoticeService.removeById(noticeId);
        return success ? R.ok("Collection notice deleted successfully") : R.failed("Failed to delete collection notice");
    }
}

