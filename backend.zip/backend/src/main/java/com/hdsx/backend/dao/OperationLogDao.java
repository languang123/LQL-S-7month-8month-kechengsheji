package com.hdsx.backend.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hdsx.backend.entity.OperationLog;
import org.apache.ibatis.annotations.Mapper;

/**
 * (OperationLog)表数据库访问层
 *
 * @author makejava
 * @since 2023-08-01 11:47:55
 */
@Mapper
public interface OperationLogDao extends BaseMapper<OperationLog> {

}

