package com.hdsx.backend.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.UnitProfile;
import com.hdsx.backend.service.UnitProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * (UnitProfile)表控制层
 *
 * @author makejava
 * @since 2023-08-01 11:47:56
 */
//单位基本信息管理
@RestController
@RequestMapping("/api/unit-profile")
public class UnitProfileController extends ApiController {

    @Autowired
    private UnitProfileService unitProfileService;

    @PostMapping("/add")
    public R<?> addUnitProfile(@RequestBody UnitProfile unitProfile) {
        boolean success = unitProfileService.save(unitProfile);
        return success ? R.ok("Unit profile added successfully") : R.failed("Failed to add unit profile");
    }

    @PostMapping("/edit")
    public R<?> editUnitProfile(@RequestBody UnitProfile unitProfile) {
        boolean success = unitProfileService.updateById(unitProfile);
        return success ? R.ok("Unit profile edited successfully") : R.failed("Failed to edit unit profile");
    }

    @DeleteMapping("/delete/{unitId}")
    public R<?> deleteUnitProfile(@PathVariable Long unitId) {
        boolean success = unitProfileService.removeById(unitId);
        return success ? R.ok("Unit profile deleted successfully") : R.failed("Failed to delete unit profile");
    }

    @GetMapping("/get/{unitId}")
    public R<UnitProfile> getUnitProfile(@PathVariable Long unitId) {
        return R.ok(unitProfileService.getById(unitId));
    }

    @GetMapping("/search")
    public R<List<UnitProfile>> searchUnitProfiles(@RequestParam String fieldName, @RequestParam String value) {
        QueryWrapper<UnitProfile> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(fieldName, value);
        List<UnitProfile> unitProfiles = unitProfileService.list(queryWrapper);
        return R.ok(unitProfiles); // Assuming R.ok() creates a success response
    }

    @GetMapping("/list")
    public R<List<UnitProfile>> getAllUnitProfiles() {
        return R.ok(unitProfileService.list());
    }

    @GetMapping("/list-paged")
    public R<Page<UnitProfile>> getPagedUnitProfiles(@RequestParam(defaultValue = "1") long current,
                                                     @RequestParam(defaultValue = "10") long size) {
        Page<UnitProfile> page = new Page<>(current, size);
        return R.ok(unitProfileService.page(page));
    }
}