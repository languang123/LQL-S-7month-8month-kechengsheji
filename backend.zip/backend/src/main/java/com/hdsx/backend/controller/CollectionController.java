package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.Collection;
import com.hdsx.backend.service.CollectionService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * (Collection)表控制层
 *
 * @author makejava
 * @since 2023-08-01 11:47:53
 */
//保障金征收监管
@RestController
@RequestMapping("/api/collection")
public class CollectionController extends ApiController {

    @Resource
    private CollectionService collectionService;

    @GetMapping("/list")
    public R<List<Collection>> getAllCollections(Collection collection) {
        List<Collection> collections = collectionService.list(new QueryWrapper<>(collection));
        return R.ok(collections);
    }

    @GetMapping("/list-paged")
    public R<Page<Collection>> getPagedCollections(@RequestParam(defaultValue = "1") long current,
                                                   @RequestParam(defaultValue = "10") long size,
                                                   Collection collection) {
        Page<Collection> page = new Page<>(current, size);
        collectionService.page(page, new QueryWrapper<>(collection));
        return R.ok(page);
    }

    @GetMapping("/get/{id}")
    public R<Collection> getCollectionById(@PathVariable Serializable id) {
        return R.ok(collectionService.getById(id));
    }

    @PostMapping("/add")
    public R<String> addCollection(@RequestBody Collection collection) {
        boolean success = collectionService.save(collection);
        return success ? R.ok("Collection added successfully") : R.failed("Failed to add collection");
    }

    @PostMapping("/edit")
    public R<String> editCollection(@RequestBody Collection collection) {
        boolean success = collectionService.updateById(collection);
        return success ? R.ok("Collection edited successfully") : R.failed("Failed to edit collection");
    }

    @DeleteMapping("/delete/{collectionId}")
    public R<?> deleteCollection(@PathVariable Long collectionId) {
        boolean success = collectionService.removeById(collectionId);
        return success ? R.ok("Collection deleted successfully") : R.failed("Failed to delete collection");
    }

}

