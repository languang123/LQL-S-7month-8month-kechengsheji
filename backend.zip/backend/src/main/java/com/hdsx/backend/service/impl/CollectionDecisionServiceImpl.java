package com.hdsx.backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hdsx.backend.dao.CollectionDecisionDao;
import com.hdsx.backend.entity.CollectionDecision;
import com.hdsx.backend.service.CollectionDecisionService;
import org.springframework.stereotype.Service;

/**
 * (CollectionDecision)表服务实现类
 *
 * @author makejava
 * @since 2023-08-01 11:47:53
 */
@Service("collectionDecisionService")
public class CollectionDecisionServiceImpl extends ServiceImpl<CollectionDecisionDao, CollectionDecision> implements CollectionDecisionService {

}

