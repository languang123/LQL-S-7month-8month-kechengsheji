package com.hdsx.backend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hdsx.backend.entity.CollectionDecision;

/**
 * (CollectionDecision)表服务接口
 *
 * @author makejava
 * @since 2023-08-01 11:47:53
 */
public interface CollectionDecisionService extends IService<CollectionDecision> {

}

