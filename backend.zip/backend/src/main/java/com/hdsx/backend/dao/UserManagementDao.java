package com.hdsx.backend.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hdsx.backend.entity.UserManagement;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * (UserManagement)表数据库访问层
 *
 * @author makejava
 * @since 2023-08-01 11:47:53
 */
@Mapper
public interface UserManagementDao extends BaseMapper<UserManagement> {

}

