package com.hdsx.backend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hdsx.backend.entity.Expenditure;

/**
 * (Expenditure)表服务接口
 *
 * @author makejava
 * @since 2023-08-01 11:47:54
 */
public interface ExpenditureService extends IService<Expenditure> {

}

