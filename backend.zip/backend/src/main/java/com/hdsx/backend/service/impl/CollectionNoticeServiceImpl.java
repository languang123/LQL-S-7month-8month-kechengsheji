package com.hdsx.backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hdsx.backend.dao.CollectionNoticeDao;
import com.hdsx.backend.entity.CollectionNotice;
import com.hdsx.backend.service.CollectionNoticeService;
import org.springframework.stereotype.Service;

/**
 * (CollectionNotice)表服务实现类
 *
 * @author makejava
 * @since 2023-08-01 11:47:53
 */
@Service("collectionNoticeService")
public class CollectionNoticeServiceImpl extends ServiceImpl<CollectionNoticeDao, CollectionNotice> implements CollectionNoticeService {

}

