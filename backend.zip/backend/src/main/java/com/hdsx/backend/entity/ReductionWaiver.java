package com.hdsx.backend.entity;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.io.Serializable;

/**
 * (ReductionWaiver)表实体类
 *
 * @author makejava
 * @since 2023-08-01 11:47:56
 */
@SuppressWarnings("serial")
public class ReductionWaiver extends Model<ReductionWaiver> {
    //减免/缓交编号
    @TableId
    private Long reductionWaiverId;
    //所属单位的编号
    private Long unitId;
    //减免/缓交原因
    private String reductionReason;
    //减免/缓交金额
    private Double reductionAmount;
    //减免/缓交日期
    private Date reductionData;


    public Long getReductionWaiverId() {
        return reductionWaiverId;
    }

    public void setReductionWaiverId(Long reductionWaiverId) {
        this.reductionWaiverId = reductionWaiverId;
    }

    public Long getUnitId() {
        return unitId;
    }

    public void setUnitId(Long unitId) {
        this.unitId = unitId;
    }

    public String getReductionReason() {
        return reductionReason;
    }

    public void setReductionReason(String reductionReason) {
        this.reductionReason = reductionReason;
    }

    public Double getReductionAmount() {
        return reductionAmount;
    }

    public void setReductionAmount(Double reductionAmount) {
        this.reductionAmount = reductionAmount;
    }

    public Date getReductionData() {
        return reductionData;
    }

    public void setReductionData(Date reductionData) {
        this.reductionData = reductionData;
    }

    /**
     * 获取主键值
     *
     * @return 主键值
     */
    @Override
    protected Serializable pkVal() {
        return this.reductionWaiverId;
    }
}

