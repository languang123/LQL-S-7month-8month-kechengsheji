package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.UnitEmployee;
import com.hdsx.backend.service.UnitEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;

/**
 * (UnitEmployee)表控制层
 *
 * @author makejava
 * @since 2023-08-06 14:39:16
 */
//单位人员信息管理
@RestController
@RequestMapping("/api/unit-employee")
public class UnitEmployeeController extends ApiController {

    @Autowired
    private UnitEmployeeService unitEmployeeService;

    @PostMapping("/add")
    public R<String> addEmployee(@RequestBody UnitEmployee unitEmployee) {
        boolean success = unitEmployeeService.save(unitEmployee);
        return success ? R.ok("Employee added successfully") : R.failed("Failed to add employee");
    }

    @PostMapping("/edit")
    public R<String> editEmployee(@RequestBody UnitEmployee unitEmployee) {
        boolean success = unitEmployeeService.updateById(unitEmployee);
        return success ? R.ok("Employee edited successfully") : R.failed("Failed to edit employee");
    }

    @DeleteMapping("/delete/{employeeId}")
    public R<String> deleteEmployee(@PathVariable Long employeeId) {
        boolean success = unitEmployeeService.removeById(employeeId);
        return success ? R.ok("Employee deleted successfully") : R.failed("Failed to delete employee");
    }

    @GetMapping("/get/{employeeId}")
    public R<UnitEmployee> getEmployee(@PathVariable Long employeeId) {
        return R.ok(unitEmployeeService.getById(employeeId));
    }

    @GetMapping("/list")
    public R<List<UnitEmployee>> getAllEmployees() {
        return R.ok(unitEmployeeService.list());
    }

    @GetMapping("/list-paged")
    public R<Page<UnitEmployee>> getPagedEmployees(@RequestParam(defaultValue = "1") long current,
                                                   @RequestParam(defaultValue = "10") long size) {
        Page<UnitEmployee> page = new Page<>(current, size);
        return R.ok(unitEmployeeService.page(page));
    }
}

