package com.hdsx.backend.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.io.Serializable;

/**
 * (UnitType)表实体类
 *
 * @author makejava
 * @since 2023-08-01 11:47:56
 */
@SuppressWarnings("serial")
public class UnitType extends Model<UnitType> {
    //类型编号
    @TableId
    private Long typeId;
    //类型名称
    private String typeName;
    //类型描述
    private String typeDesc;


    public Long getTypeId() {
        return typeId;
    }

    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getTypeDesc() {
        return typeDesc;
    }

    public void setTypeDesc(String typeDesc) {
        this.typeDesc = typeDesc;
    }

    /**
     * 获取主键值
     *
     * @return 主键值
     */
    @Override
    protected Serializable pkVal() {
        return this.typeId;
    }
}

