package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.CollectionStatistics;
import com.hdsx.backend.service.CollectionStatisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;
import java.util.List;

/**
 * (CollectionStatistics)表控制层
 *
 * @author makejava
 * @since 2023-08-01 11:47:53
 */
@RestController
@RequestMapping("/api/collection-statistics")
public class CollectionStatisticsController {

    @Autowired
    private CollectionStatisticsService collectionStatisticsService;

    @GetMapping("/list")
    public R<List<CollectionStatistics>> getAllCollectionStatistics(CollectionStatistics collectionStatistics) {
        List<CollectionStatistics> collectionStatisticsList = collectionStatisticsService.list(new QueryWrapper<>(collectionStatistics));
        return R.ok(collectionStatisticsList);
    }

    @GetMapping("/list-paged")
    public R<Page<CollectionStatistics>> getPagedCollectionStatistics(@RequestParam(defaultValue = "1") long current,
                                                                      @RequestParam(defaultValue = "10") long size,
                                                                      CollectionStatistics collectionStatistics) {
        Page<CollectionStatistics> page = new Page<>(current, size);
        collectionStatisticsService.page(page, new QueryWrapper<>(collectionStatistics));
        return R.ok(page);
    }

    @GetMapping("/get/{id}")
    public R<CollectionStatistics> getCollectionStatisticsById(@PathVariable Serializable id) {
        return R.ok(collectionStatisticsService.getById(id));
    }

    @PostMapping("/add")
    public R<String> addCollectionStatistics(@RequestBody CollectionStatistics collectionStatistics) {
        boolean success = collectionStatisticsService.save(collectionStatistics);
        return success ? R.ok("Collection statistics added successfully") : R.failed("Failed to add collection statistics");
    }

    @PostMapping("/edit")
    public R<String> editCollectionStatistics(@RequestBody CollectionStatistics collectionStatistics) {
        boolean success = collectionStatisticsService.updateById(collectionStatistics);
        return success ? R.ok("Collection statistics edited successfully") : R.failed("Failed to edit collection statistics");
    }

    @DeleteMapping("/delete/{statisticId}")
    public R<?> deleteCollectionStatistics(@PathVariable Long statisticId) {
        boolean success = collectionStatisticsService.removeById(statisticId);
        return success ? R.ok("Collection statistics deleted successfully") : R.failed("Failed to delete collection statistics");
    }

}

