package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.CollectionDecision;
import com.hdsx.backend.service.CollectionDecisionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * (CollectionDecision)表控制层
 *
 * @author makejava
 * @since 2023-08-01 11:47:53
 */

@RestController
@RequestMapping("/api/collection-decision")
public class CollectionDecisionController {

    @Autowired
    private CollectionDecisionService collectionDecisionService;

    @GetMapping("/list")
    public R<List<CollectionDecision>> getAllCollectionDecisions(CollectionDecision collectionDecision) {
        List<CollectionDecision> collectionDecisions = collectionDecisionService.list(new QueryWrapper<>(collectionDecision));
        return R.ok(collectionDecisions);
    }

    @GetMapping("/list-paged")
    public R<Page<CollectionDecision>> getPagedCollectionDecisions(@RequestParam(defaultValue = "1") long current,
                                                                   @RequestParam(defaultValue = "10") long size,
                                                                   CollectionDecision collectionDecision) {
        Page<CollectionDecision> page = new Page<>(current, size);
        collectionDecisionService.page(page, new QueryWrapper<>(collectionDecision));
        return R.ok(page);
    }

    @GetMapping("/get/{id}")
    public R<CollectionDecision> getCollectionDecisionById(@PathVariable Serializable id) {
        return R.ok(collectionDecisionService.getById(id));
    }

    @PostMapping("/add")
    public R<String> addCollectionDecision(@RequestBody CollectionDecision collectionDecision) {
        boolean success = collectionDecisionService.save(collectionDecision);
        return success ? R.ok("Collection decision added successfully") : R.failed("Failed to add collection decision");
    }

    @PostMapping("/edit")
    public R<String> editCollectionDecision(@RequestBody CollectionDecision collectionDecision) {
        boolean success = collectionDecisionService.updateById(collectionDecision);
        return success ? R.ok("Collection decision edited successfully") : R.failed("Failed to edit collection decision");
    }

    @DeleteMapping("/delete/{decisionId}")
    public R<?> deleteCollectionDecisions(@PathVariable Long decisionId) {
        boolean success = collectionDecisionService.removeById(decisionId);
        return success ? R.ok("Collection decision deleted successfully") : R.failed("Failed to delete collection decision");
    }

}

