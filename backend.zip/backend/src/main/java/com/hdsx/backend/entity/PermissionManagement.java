package com.hdsx.backend.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.io.Serializable;

/**
 * (PermissionManagement)表实体类
 *
 * @author makejava
 * @since 2023-08-01 11:47:55
 */
@SuppressWarnings("serial")
public class PermissionManagement extends Model<PermissionManagement> {
    //权限编号
    @TableId
    private Long permissionId;
    //角色名称
    private String roleName;
    //权限名称
    private String permissionName;
    //权限描述
    private String permissionDescription;


    public Long getPermissionId() {
        return permissionId;
    }

    public void setPermissionId(Long permissionId) {
        this.permissionId = permissionId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getPermissionName() {
        return permissionName;
    }

    public void setPermissionName(String permissionName) {
        this.permissionName = permissionName;
    }

    public String getPermissionDescription() {
        return permissionDescription;
    }

    public void setPermissionDescription(String permissionDescription) {
        this.permissionDescription = permissionDescription;
    }

    /**
     * 获取主键值
     *
     * @return 主键值
     */
    @Override
    protected Serializable pkVal() {
        return this.permissionId;
    }
}

