package com.hdsx.backend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hdsx.backend.entity.ReductionWaiver;

/**
 * (ReductionWaiver)表服务接口
 *
 * @author makejava
 * @since 2023-08-06 14:41:47
 */
public interface ReductionWaiverService extends IService<ReductionWaiver> {

}

