package com.hdsx.backend.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hdsx.backend.entity.ReductionWaiver;
import org.apache.ibatis.annotations.Mapper;

/**
 * (ReductionWaiver)表数据库访问层
 *
 * @author makejava
 * @since 2023-08-06 14:41:47
 */
@Mapper
public interface ReductionWaiverDao extends BaseMapper<ReductionWaiver> {

}

