package com.hdsx.backend.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hdsx.backend.entity.UnitProfile;
import org.apache.ibatis.annotations.Mapper;

/**
 * (UnitProfile)表数据库访问层
 *
 * @author makejava
 * @since 2023-08-01 11:47:56
 */
@Mapper
public interface UnitProfileDao extends BaseMapper<UnitProfile> {

}

