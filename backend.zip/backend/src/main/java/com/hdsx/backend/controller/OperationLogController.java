package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.OperationLog;
import com.hdsx.backend.service.OperationLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * (OperationLog)表控制层
 *
 * @author makejava
 * @since 2023-08-01 11:47:54
 */
@RestController
@RequestMapping("/api/operation-log")
public class OperationLogController {

    @Autowired
    private OperationLogService operationLogService;

    @GetMapping("/list")
    public R<List<OperationLog>> getAllOperationLogs(OperationLog operationLog) {
        List<OperationLog> operationLogs = operationLogService.list(new QueryWrapper<>(operationLog));
        return R.ok(operationLogs);
    }

    @GetMapping("/list-paged")
    public R<Page<OperationLog>> getPagedOperationLogs(@RequestParam(defaultValue = "1") long current,
                                                       @RequestParam(defaultValue = "10") long size,
                                                       OperationLog operationLog) {
        Page<OperationLog> page = new Page<>(current, size);
        operationLogService.page(page, new QueryWrapper<>(operationLog));
        return R.ok(page);
    }

    @GetMapping("/get/{id}")
    public R<OperationLog> getOperationLogById(@PathVariable Serializable id) {
        return R.ok(operationLogService.getById(id));
    }

    @PostMapping("/add")
    public R<String> addOperationLog(@RequestBody OperationLog operationLog) {
        boolean success = operationLogService.save(operationLog);
        return success ? R.ok("Operation log added successfully") : R.failed("Failed to add operation log");
    }

    @PostMapping("/edit")
    public R<String> editOperationLog(@RequestBody OperationLog operationLog) {
        boolean success = operationLogService.updateById(operationLog);
        return success ? R.ok("Operation log edited successfully") : R.failed("Failed to edit operation log");
    }

    @DeleteMapping("/delete/{logId}")
    public R<?> deleteOperationLogs(@PathVariable Long logId) {
        boolean success = operationLogService.removeById(logId);
        return success ? R.ok("Operation log deleted successfully") : R.failed("Failed to delete Operation log");
    }

}

