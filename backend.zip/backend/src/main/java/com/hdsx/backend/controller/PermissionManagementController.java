package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.PermissionManagement;
import com.hdsx.backend.service.PermissionManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * (PermissionManagement)表控制层
 *
 * @author makejava
 * @since 2023-08-01 11:47:55
 */
@RestController
@RequestMapping("/api/permission-management")
public class PermissionManagementController {

    @Autowired
    private PermissionManagementService permissionManagementService;

    @GetMapping("/list")
    public R<List<PermissionManagement>> getAllPermissionManagements(PermissionManagement permissionManagement) {
        List<PermissionManagement> permissionManagements = permissionManagementService.list(new QueryWrapper<>(permissionManagement));
        return R.ok(permissionManagements);
    }

    @GetMapping("/list-paged")
    public R<Page<PermissionManagement>> getPagedPermissionManagements(@RequestParam(defaultValue = "1") long current,
                                                                       @RequestParam(defaultValue = "10") long size,
                                                                       PermissionManagement permissionManagement) {
        Page<PermissionManagement> page = new Page<>(current, size);
        permissionManagementService.page(page, new QueryWrapper<>(permissionManagement));
        return R.ok(page);
    }

    @GetMapping("/get/{id}")
    public R<PermissionManagement> getPermissionManagementById(@PathVariable Serializable id) {
        return R.ok(permissionManagementService.getById(id));
    }

    @PostMapping("/add")
    public R<String> addPermissionManagement(@RequestBody PermissionManagement permissionManagement) {
        boolean success = permissionManagementService.save(permissionManagement);
        return success ? R.ok("Permission management added successfully") : R.failed("Failed to add permission management");
    }

    @PostMapping("/edit")
    public R<String> editPermissionManagement(@RequestBody PermissionManagement permissionManagement) {
        boolean success = permissionManagementService.updateById(permissionManagement);
        return success ? R.ok("Permission management edited successfully") : R.failed("Failed to edit permission management");
    }

    @DeleteMapping("/delete/{permissionId}")
    public R<?> deletePermissionManagements(@PathVariable Long permissionId) {
        boolean success = permissionManagementService.removeById(permissionId);
        return success ? R.ok("Permission managements deleted successfully") : R.failed("Failed to delete permission managements");
    }

}

