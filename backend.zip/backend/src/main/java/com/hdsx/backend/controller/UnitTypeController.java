package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.UnitType;
import com.hdsx.backend.service.UnitTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * (UnitType)表控制层
 *
 * @author makejava
 * @since 2023-08-01 11:47:56
 */
@RestController
@RequestMapping("/api/unit-type")
public class UnitTypeController {

    @Autowired
    private UnitTypeService unitTypeService;

    @GetMapping("/list")
    public R<List<UnitType>> getAllUnitTypes(UnitType unitType) {
        List<UnitType> unitTypes = unitTypeService.list(new QueryWrapper<>(unitType));
        return R.ok(unitTypes);
    }

    @GetMapping("/list-paged")
    public R<Page<UnitType>> getPagedUnitTypes(@RequestParam(defaultValue = "1") long current,
                                               @RequestParam(defaultValue = "10") long size,
                                               UnitType unitType) {
        Page<UnitType> page = new Page<>(current, size);
        unitTypeService.page(page, new QueryWrapper<>(unitType));
        return R.ok(page);
    }

    @GetMapping("/get/{id}")
    public R<UnitType> getUnitTypeById(@PathVariable Serializable id) {
        return R.ok(unitTypeService.getById(id));
    }

    @PostMapping("/add")
    public R<String> addUnitType(@RequestBody UnitType unitType) {
        boolean success = unitTypeService.save(unitType);
        return success ? R.ok("Unit type added successfully") : R.failed("Failed to add unit type");
    }

    @PostMapping("/edit")
    public R<String> editUnitType(@RequestBody UnitType unitType) {
        boolean success = unitTypeService.updateById(unitType);
        return success ? R.ok("Unit type edited successfully") : R.failed("Failed to edit unit type");
    }

    @DeleteMapping("/delete/{typeId}")
    public R<?> deleteUnitTypes(@PathVariable Long typeId) {
        boolean success = unitTypeService.removeById(typeId);
        return success ? R.ok("Unit types deleted successfully") : R.failed("Failed to delete unit types");
    }

}

