package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.ReductionWaiver;
import com.hdsx.backend.service.ReductionWaiverService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * (ReductionWaiver)表控制层
 *
 * @author makejava
 * @since 2023-08-06 14:41:46
 */
//减、免、缓交保障金管理
@RestController
@RequestMapping("/api/reduction-waiver")
public class ReductionWaiverController {

    @Autowired
    private ReductionWaiverService reductionWaiverService;

    @GetMapping("/list")
    public R<List<ReductionWaiver>> getAllReductionWaivers(ReductionWaiver reductionWaiver) {
        List<ReductionWaiver> reductionWaivers = reductionWaiverService.list(new QueryWrapper<>(reductionWaiver));
        return R.ok(reductionWaivers);
    }

    @GetMapping("/list-paged")
    public R<Page<ReductionWaiver>> getPagedReductionWaivers(@RequestParam(defaultValue = "1") long current,
                                                             @RequestParam(defaultValue = "10") long size,
                                                             ReductionWaiver reductionWaiver) {
        Page<ReductionWaiver> page = new Page<>(current, size);
        reductionWaiverService.page(page, new QueryWrapper<>(reductionWaiver));
        return R.ok(page);
    }

    @GetMapping("/get/{id}")
    public R<ReductionWaiver> getReductionWaiverById(@PathVariable Serializable id) {
        return R.ok(reductionWaiverService.getById(id));
    }

    @PostMapping("/add")
    public R<String> addReductionWaiver(@RequestBody ReductionWaiver reductionWaiver) {
        boolean success = reductionWaiverService.save(reductionWaiver);
        return success ? R.ok("Reduction waiver added successfully") : R.failed("Failed to add reduction waiver");
    }

    @PostMapping("/edit")
    public R<String> editReductionWaiver(@RequestBody ReductionWaiver reductionWaiver) {
        boolean success = reductionWaiverService.updateById(reductionWaiver);
        return success ? R.ok("Reduction waiver edited successfully") : R.failed("Failed to edit reduction waiver");
    }

    @DeleteMapping("/delete/{reductionWaiverId}")
    public R<?> deleteReductionWaivers(@PathVariable Long reductionWaiverId) {
        boolean success = reductionWaiverService.removeById(reductionWaiverId);
        return success ? R.ok("Reduction waivers deleted successfully") : R.failed("Failed to delete reduction waivers");
    }

}

