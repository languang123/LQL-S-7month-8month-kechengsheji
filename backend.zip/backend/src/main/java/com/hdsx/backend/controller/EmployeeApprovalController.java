package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.EmployeeApproval;
import com.hdsx.backend.service.EmployeeApprovalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * (EmployeeApproval)表控制层
 *
 * @author makejava
 * @since 2023-08-01 11:47:54
 */
@RestController
@RequestMapping("/api/employee-approval")
public class EmployeeApprovalController {

    @Autowired
    private EmployeeApprovalService employeeApprovalService;

    @GetMapping("/list")
    public R<List<EmployeeApproval>> getAllEmployeeApprovals(EmployeeApproval employeeApproval) {
        List<EmployeeApproval> employeeApprovals = employeeApprovalService.list(new QueryWrapper<>(employeeApproval));
        return R.ok(employeeApprovals);
    }

    @GetMapping("/list-paged")
    public R<Page<EmployeeApproval>> getPagedEmployeeApprovals(@RequestParam(defaultValue = "1") long current,
                                                               @RequestParam(defaultValue = "10") long size,
                                                               EmployeeApproval employeeApproval) {
        Page<EmployeeApproval> page = new Page<>(current, size);
        employeeApprovalService.page(page, new QueryWrapper<>(employeeApproval));
        return R.ok(page);
    }

    @GetMapping("/get/{id}")
    public R<EmployeeApproval> getEmployeeApprovalById(@PathVariable Serializable id) {
        return R.ok(employeeApprovalService.getById(id));
    }

    @PostMapping("/add")
    public R<String> addEmployeeApproval(@RequestBody EmployeeApproval employeeApproval) {
        boolean success = employeeApprovalService.save(employeeApproval);
        return success ? R.ok("Employee approval added successfully") : R.failed("Failed to add employee approval");
    }

    @PostMapping("/edit")
    public R<String> editEmployeeApproval(@RequestBody EmployeeApproval employeeApproval) {
        boolean success = employeeApprovalService.updateById(employeeApproval);
        return success ? R.ok("Employee approval edited successfully") : R.failed("Failed to edit employee approval");
    }

    @DeleteMapping("/delete/{approvalId}")
    public R<?> deleteEmployeeApprovals(@PathVariable Long approvalId) {
        boolean success = employeeApprovalService.removeById(approvalId);
        return success ? R.ok("Employee approval deleted successfully") : R.failed("Failed to delete employee approval");
    }

}
