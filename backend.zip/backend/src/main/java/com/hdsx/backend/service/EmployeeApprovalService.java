package com.hdsx.backend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hdsx.backend.entity.EmployeeApproval;

/**
 * (EmployeeApproval)表服务接口
 *
 * @author makejava
 * @since 2023-08-01 11:47:54
 */
public interface EmployeeApprovalService extends IService<EmployeeApproval> {

}

