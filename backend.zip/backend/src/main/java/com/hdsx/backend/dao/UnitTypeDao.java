package com.hdsx.backend.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hdsx.backend.entity.UnitType;
import org.apache.ibatis.annotations.Mapper;

/**
 * (UnitType)表数据库访问层
 *
 * @author makejava
 * @since 2023-08-01 11:47:56
 */
@Mapper
public interface UnitTypeDao extends BaseMapper<UnitType> {

}

