package com.hdsx.backend.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.io.Serializable;

/**
 * (RoleManagement)表实体类
 *
 * @author makejava
 * @since 2023-08-01 11:47:56
 */
@SuppressWarnings("serial")
public class RoleManagement extends Model<RoleManagement> {
    //角色编号
    @TableId
    private Long roleId;
    //角色名称
    private String roleName;
    //角色描述
    private String roleDesc;


    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getRoleDesc() {
        return roleDesc;
    }

    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    /**
     * 获取主键值
     *
     * @return 主键值
     */
    @Override
    protected Serializable pkVal() {
        return this.roleId;
    }
}

