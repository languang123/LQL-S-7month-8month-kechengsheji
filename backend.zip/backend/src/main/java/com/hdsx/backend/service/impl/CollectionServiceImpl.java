package com.hdsx.backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hdsx.backend.dao.CollectionDao;
import com.hdsx.backend.entity.Collection;
import com.hdsx.backend.service.CollectionService;
import org.springframework.stereotype.Service;

/**
 * (Collection)表服务实现类
 *
 * @author makejava
 * @since 2023-08-01 11:47:53
 */
@Service("collectionService")
public class CollectionServiceImpl extends ServiceImpl<CollectionDao, Collection> implements CollectionService {

}

