package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.Expenditure;
import com.hdsx.backend.service.ExpenditureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * (Expenditure)表控制层
 *
 * @author makejava
 * @since 2023-08-01 11:47:54
 */
@RestController
@RequestMapping("/api/expenditure")
public class ExpenditureController {

    @Autowired
    private ExpenditureService expenditureService;

    @GetMapping("/list")
    public R<List<Expenditure>> getAllExpenditures(Expenditure expenditure) {
        List<Expenditure> expenditures = expenditureService.list(new QueryWrapper<>(expenditure));
        return R.ok(expenditures);
    }

    @GetMapping("/list-paged")
    public R<Page<Expenditure>> getPagedExpenditures(@RequestParam(defaultValue = "1") long current,
                                                     @RequestParam(defaultValue = "10") long size,
                                                     Expenditure expenditure) {
        Page<Expenditure> page = new Page<>(current, size);
        expenditureService.page(page, new QueryWrapper<>(expenditure));
        return R.ok(page);
    }

    @GetMapping("/get/{id}")
    public R<Expenditure> getExpenditureById(@PathVariable Serializable id) {
        return R.ok(expenditureService.getById(id));
    }

    @PostMapping("/add")
    public R<String> addExpenditure(@RequestBody Expenditure expenditure) {
        boolean success = expenditureService.save(expenditure);
        return success ? R.ok("Expenditure added successfully") : R.failed("Failed to add expenditure");
    }

    @PostMapping("/edit")
    public R<String> editExpenditure(@RequestBody Expenditure expenditure) {
        boolean success = expenditureService.updateById(expenditure);
        return success ? R.ok("Expenditure edited successfully") : R.failed("Failed to edit expenditure");
    }

    @DeleteMapping("/delete/{expenditureId}")
    public R<?> deleteExpenditures(@PathVariable Long expenditureId) {
        boolean success = expenditureService.removeById(expenditureId);
        return success ? R.ok("Expenditure deleted successfully") : R.failed("Failed to delete expenditure");
    }

}

