package com.hdsx.backend.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hdsx.backend.dao.UnitProfileDao;
import com.hdsx.backend.entity.UnitProfile;
import com.hdsx.backend.service.UnitProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * (UnitProfile)表服务实现类
 *
 * @author makejava
 * @since 2023-08-01 11:47:56
 */
@Service("unitProfileService")
public class UnitProfileServiceImpl extends ServiceImpl<UnitProfileDao, UnitProfile> implements UnitProfileService {

}

