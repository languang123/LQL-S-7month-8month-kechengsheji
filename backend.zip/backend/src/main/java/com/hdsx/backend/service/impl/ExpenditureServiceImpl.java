package com.hdsx.backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hdsx.backend.dao.ExpenditureDao;
import com.hdsx.backend.entity.Expenditure;
import com.hdsx.backend.service.ExpenditureService;
import org.springframework.stereotype.Service;

/**
 * (Expenditure)表服务实现类
 *
 * @author makejava
 * @since 2023-08-01 11:47:54
 */
@Service("expenditureService")
public class ExpenditureServiceImpl extends ServiceImpl<ExpenditureDao, Expenditure> implements ExpenditureService {

}

