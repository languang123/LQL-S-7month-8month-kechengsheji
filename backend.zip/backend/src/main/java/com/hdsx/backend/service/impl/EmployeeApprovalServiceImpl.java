package com.hdsx.backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hdsx.backend.dao.EmployeeApprovalDao;
import com.hdsx.backend.entity.EmployeeApproval;
import com.hdsx.backend.service.EmployeeApprovalService;
import org.springframework.stereotype.Service;

/**
 * (EmployeeApproval)表服务实现类
 *
 * @author makejava
 * @since 2023-08-01 11:47:54
 */
@Service("employeeApprovalService")
public class EmployeeApprovalServiceImpl extends ServiceImpl<EmployeeApprovalDao, EmployeeApproval> implements EmployeeApprovalService {

}

