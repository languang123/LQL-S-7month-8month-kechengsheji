package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.DataBackupRestore;
import com.hdsx.backend.service.DataBackupRestoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * (DataBackupRestore)表控制层
 *
 * @author makejava
 * @since 2023-08-01 11:47:54
 */
@RestController
@RequestMapping("/api/data-backup-restore")
public class DataBackupRestoreController {

    @Autowired
    private DataBackupRestoreService dataBackupRestoreService;

    @GetMapping("/list")
    public R<List<DataBackupRestore>> getAllDataBackupRestores(DataBackupRestore dataBackupRestore) {
        List<DataBackupRestore> dataBackupRestores = dataBackupRestoreService.list(new QueryWrapper<>(dataBackupRestore));
        return R.ok(dataBackupRestores);
    }

    @GetMapping("/list-paged")
    public R<Page<DataBackupRestore>> getPagedDataBackupRestores(@RequestParam(defaultValue = "1") long current,
                                                                 @RequestParam(defaultValue = "10") long size,
                                                                 DataBackupRestore dataBackupRestore) {
        Page<DataBackupRestore> page = new Page<>(current, size);
        dataBackupRestoreService.page(page, new QueryWrapper<>(dataBackupRestore));
        return R.ok(page);
    }

    @GetMapping("/get/{id}")
    public R<DataBackupRestore> getDataBackupRestoreById(@PathVariable Serializable id) {
        return R.ok(dataBackupRestoreService.getById(id));
    }

    @PostMapping("/add")
    public R<String> addDataBackupRestore(@RequestBody DataBackupRestore dataBackupRestore) {
        boolean success = dataBackupRestoreService.save(dataBackupRestore);
        return success ? R.ok("Data backup restore added successfully") : R.failed("Failed to add data backup restore");
    }

    @PostMapping("/edit")
    public R<String> editDataBackupRestore(@RequestBody DataBackupRestore dataBackupRestore) {
        boolean success = dataBackupRestoreService.updateById(dataBackupRestore);
        return success ? R.ok("Data backup restore edited successfully") : R.failed("Failed to edit data backup restore");
    }

    @DeleteMapping("/delete/{backupId}")
    public R<?> deleteDataBackupRestore(@PathVariable Long backupId) {
        boolean success = dataBackupRestoreService.removeById(backupId);
        return success ? R.ok("Data backup restore deleted successfully") : R.failed("Failed to delete data backup restore");
    }

}

