package com.hdsx.backend.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hdsx.backend.entity.UnitEmployee;
import org.apache.ibatis.annotations.Mapper;

/**
 * (UnitEmployee)表数据库访问层
 *
 * @author makejava
 * @since 2023-08-06 14:39:16
 */
@Mapper
public interface UnitEmployeeDao extends BaseMapper<UnitEmployee> {

}

