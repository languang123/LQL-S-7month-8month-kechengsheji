package com.hdsx.backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hdsx.backend.dao.CollectionStatisticsDao;
import com.hdsx.backend.entity.CollectionStatistics;
import com.hdsx.backend.service.CollectionStatisticsService;
import org.springframework.stereotype.Service;

/**
 * (CollectionStatistics)表服务实现类
 *
 * @author makejava
 * @since 2023-08-01 11:47:54
 */
@Service("collectionStatisticsService")
public class CollectionStatisticsServiceImpl extends ServiceImpl<CollectionStatisticsDao, CollectionStatistics> implements CollectionStatisticsService {

}

