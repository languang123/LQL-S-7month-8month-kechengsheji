package com.hdsx.backend.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hdsx.backend.entity.UserManagement;
import com.hdsx.backend.service.UserManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * (UserManagement)表控制层
 *
 * @author makejava
 * @since 2023-08-01 11:47:56
 */
@RestController
@RequestMapping("/api/user-management")
public class UserManagementController {

    @Autowired
    private UserManagementService userManagementService;

    @GetMapping("/list")
    public R<List<UserManagement>> getAllUserManagement(UserManagement userManagement) {
        List<UserManagement> userManagements = userManagementService.list(new QueryWrapper<>(userManagement));
        return R.ok(userManagements);
    }

    @GetMapping("/list-paged")
    public R<Page<UserManagement>> getPagedUserManagements(@RequestParam(defaultValue = "1") long current,
                                                           @RequestParam(defaultValue = "10") long size,
                                                           UserManagement userManagement) {
        Page<UserManagement> page = new Page<>(current, size);
        userManagementService.page(page, new QueryWrapper<>(userManagement));
        return R.ok(page);
    }

    @GetMapping("/get/{id}")
    public R<UserManagement> getUserManagementById(@PathVariable Serializable id) {
        return R.ok(userManagementService.getById(id));
    }

    @PostMapping("/add")
    public R<String> addUserManagement(@RequestBody UserManagement userManagement) {
        boolean success = userManagementService.save(userManagement);
        return success ? R.ok("User management added successfully") : R.failed("Failed to add user management");
    }

    @PostMapping("/edit")
    public R<String> editUserManagement(@RequestBody UserManagement userManagement) {
        boolean success = userManagementService.updateById(userManagement);
        return success ? R.ok("User management edited successfully") : R.failed("Failed to edit user management");
    }

    @DeleteMapping("/delete/{userId}")
    public R<?> deleteUserManagements(@PathVariable Long userId) {
        boolean success = userManagementService.removeById(userId);
        return success ? R.ok("User management deleted successfully") : R.failed("Failed to delete user management");
    }
}

