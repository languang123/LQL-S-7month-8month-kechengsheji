package com.hdsx.backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hdsx.backend.dao.PermissionManagementDao;
import com.hdsx.backend.entity.PermissionManagement;
import com.hdsx.backend.service.PermissionManagementService;
import org.springframework.stereotype.Service;

/**
 * (PermissionManagement)表服务实现类
 *
 * @author makejava
 * @since 2023-08-01 11:47:55
 */
@Service("permissionManagementService")
public class PermissionManagementServiceImpl extends ServiceImpl<PermissionManagementDao, PermissionManagement> implements PermissionManagementService {

}

