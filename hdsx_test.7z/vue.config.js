const { defineConfig } = require('@vue/cli-service')

module.exports = {
  devServer: {
    open: true,          // 是否自动弹出浏览器页面
    port: 8080,          // 端口号 (注意这里应该是 port 而不是 host)
    https: false,        // 是否使用https协议
    proxy: {
      // 关键词
      '/api': {
        target: 'http://localhost:9090/api',  // API服务器的地址 (注意 http: 应该是 http://)
        changeOrigin: true,               // 虚拟的站点需要更换origin
        pathRewrite: {
          '^/api': ''                     // 重写路径，将 '/api' 替换为空字符串
        }
      }
    }
  }
};
