<template>
  <!-- 组件的模板内容 -->
  <div>
    <input v-model="username" type="text" placeholder="Username" />
    <input v-model="password" type="password" placeholder="Password" />
    <button @click="login">Login</button>
  </div>
</template>

<script>
// 引入 Vue 相关的 API
import { ref } from 'vue';
import axios from 'axios';

export default {
  setup() {
    // 响应式数据
    const username = ref('');
    const password = ref('');

    // 处理函数
    const login = async () => {
      try {
        const response = await axios.post('/api/login', {
          username: username.value,
          password: password.value,
        });
        console.log("ok");
        // 处理登录成功逻辑
        console.log(response.data);
      } catch (error) {
        // 处理登录失败逻辑
        console.error(error);
      }
    };

    // 返回数据和函数，以便在模板中使用
    return {
      username,
      password,
      login,
    };
  },
};
</script>

<style>
/* 可选的组件样式 */
</style>
