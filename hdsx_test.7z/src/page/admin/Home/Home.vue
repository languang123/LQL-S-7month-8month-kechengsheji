<template>
  <div class="carousel-info-scroll">
    <div class="info-scroll">
      <ul :style="{ animationDuration: animationDuration + 's' }">
        <li v-for="(info, index) in visibleInfoList" :key="index" class="info-item">
          {{ info }}
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      infoList: [
        '欢迎使用残疾人就业保障金征收及使用监管系统',
        // '欢迎使用残疾人就业保障金征收及使用监管系统',
        // '欢迎使用残疾人就业保障金征收及使用监管系统',
        // '欢迎使用残疾人就业保障金征收及使用监管系统',
        // '欢迎使用残疾人就业保障金征收及使用监管系统'
      ],
      visibleInfoList: [],
      currentInfoIndex: 0,
      animationDuration: 0
    };
  },
  mounted() {
    this.initializeInfoScroll();
  },
  methods: {
    initializeInfoScroll() {
      this.updateVisibleInfoList();
      this.startInfoScroll();
    },
    updateVisibleInfoList() {
      this.visibleInfoList = this.infoList.slice(this.currentInfoIndex).concat(this.infoList.slice(0, this.currentInfoIndex));
    },
    startInfoScroll() {
      this.animationDuration = this.infoList.length * 3; // Total duration for scrolling through all items
      
      setInterval(() => {
        this.currentInfoIndex = (this.currentInfoIndex + 1) % this.infoList.length;
        this.updateVisibleInfoList();
      }, this.animationDuration * 1000);
    }
  }
};
</script>

<style scoped>
.carousel-info-scroll {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 400px;
  overflow: hidden;
}

.info-scroll {
  font-family: myFirstFont;
  font-weight: 200;
  font-size: 40px;
  text-shadow: 5px 5px 10px grey;
  animation-timing-function: linear;
  animation-iteration-count: infinite;
  overflow: hidden;
}

.info-scroll ul {
  list-style: none;
  margin: 0;
  padding: 0;
  animation-name: scroll;
  animation-direction: normal;
  padding-left: 0;
}

.info-item {
  line-height: 2;
  animation-fill-mode: forwards;
}

@keyframes scroll {
  0% {
    transform: translateY(100%);
  }
  100% {
    transform: translateY(-100%);
  }
}
</style>
