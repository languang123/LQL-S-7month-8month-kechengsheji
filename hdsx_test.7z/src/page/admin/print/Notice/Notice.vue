<template>
  <div>
    <!-- 表头 -->
    <el-table :data="filterTableData" style="width: 100%">
      <el-table-column label="全选">
        <template #header>
          <el-checkbox v-model="selectAll" @change="handleSelectAll">全选</el-checkbox>
        </template>
        <template #default="scope">
          <!-- 在这一列添加复选框 -->
          <el-checkbox v-model="scope.row.selected" />
        </template>
      </el-table-column>

      <el-table-column label="决定书编号" prop="decisionId" />
      <el-table-column label="单位编号" prop="unitId" />
      <el-table-column label="决定日期" prop="decisionDate" />
      <el-table-column label="职工编号" prop="employeeId" />
      <el-table-column label="决定书类型" prop="decisionType" />
      <el-table-column label="决定书描述" prop="decisionDesc" />
    </el-table>

    <!-- 按钮 -->
    <el-button type="success" @click="printSelected">打印</el-button>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';

interface collection {
  decisionId: string;
  unitId: string;
  decisionDate: string;
  employeeId: string;
  decisionType: string;
  decisionDesc: string;
  selected: boolean;
}

const filterTableData = ref<collection[]>([]);
const selectAll = ref(false);

const fetchData = async () => {
  try {
    const response = await axios.get('/api/collection-decision/list');
    filterTableData.value = response.data.data.map((item: collection) => ({
      ...item,
      selected: false,
    }));
  } catch (error) {
    console.error('Fetch error:', error);
  }
};

onMounted(() => {
  fetchData();
});

const handleSelectAll = () => {
  filterTableData.value.forEach((item) => {
    item.selected = selectAll.value;
  });
};

const printSelected = () => {
  const selectedRecords = filterTableData.value.filter((item) => item.selected);

  if (selectedRecords.length === 0) {
    console.log('No records selected for printing.');
    return;
  }

  const printContent = selectedRecords.map((record) => {
    return `
      <p>决定书编号: ${record.decisionId}</p>
      <p>单位编号: ${record.unitId}</p>
      <p>决定日期: ${record.decisionDate}</p>
      <p>职工编号: ${record.employeeId}</p>
      <p>决定书类型: ${record.decisionType}</p>
      <p>决定书描述: ${record.decisionDesc}</p>
      <hr>
    `;
  }).join('');

  const printWindow = window.open('', '_blank');
  if (printWindow) {
    printWindow.document.write(`
      <html>
        <head>
          <title>打印</title>
        </head>
        <body>${printContent}</body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  } else {
    console.error('Print window could not be opened.');
  }
};
</script>

<style scoped lang="scss">
.el-checkbox__label {
  padding-left: 0;
}

.el-button[type='success'] {
  margin-top: 10px;
}
</style>
