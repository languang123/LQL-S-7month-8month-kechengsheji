<template>
    保障金征收监管
  <div>
    <el-header>
      <el-menu mode="horizontal" background-color="#545c64" text-color="#fff" active-text-color="#ffd04b">
        <el-menu-item index="1">首页</el-menu-item>
        <el-menu-item index="2">个人资料</el-menu-item>
        <el-menu-item index="3">设置</el-menu-item>
      </el-menu>
    </el-header>
    
    <el-main>
      <el-form label-width="100px" :model="form">
        <el-form-item label="姓名">
          <el-input v-model="form.name"></el-input>
        </el-form-item>
        
        <el-form-item label="年龄">
          <el-input v-model="form.age"></el-input>
        </el-form-item>
        
        <el-form-item label="班级">
          <el-input v-model="form.class"></el-input>
        </el-form-item>
        
        <el-form-item label="电话号码">
          <el-input v-model="form.phone"></el-input>
        </el-form-item>
        
        <el-form-item>
          <el-button type="primary" @click="submitForm">提交</el-button>
          <el-button @click="resetForm">重置</el-button>
        </el-form-item>
      </el-form>
    </el-main>
  </div>
</template>

<script>
export default {
  data() {
    return {
      form: {
        name: '',
        age: '',
        class: '',
        phone: ''
      }
    };
  },
  
  methods: {
    submitForm() {
      // 提交表单逻辑
    },
    
    resetForm() {
      this.form = {
        name: '',
        age: '',
        class: '',
        phone: ''
      };
    }
  }
};
</script>

<style scoped>
.el-header {
  text-align: left;
}

.el-form-item {
  margin-bottom: 20px;
}

.el-button {
  margin-right: 10px;
}
</style>