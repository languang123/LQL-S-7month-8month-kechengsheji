<template>
    <div>
      <h1>单位残疾人职工审核</h1>
      <div>
        <el-select v-model="selectedSearchType" placeholder="Select search type">
          <el-option label="员工编号" value="empoyeeId"></el-option>
          <el-option label="员工所属单位编号" value="unitId"></el-option>
          <el-option label="员工姓名" value="employeeName"></el-option>
        </el-select>
        <el-input v-model="searchText" placeholder="Type to search" style="width: 200px" />
        <el-button size="small" @click="handleSearch">Search</el-button>
      </div>
      <el-table :data="filterTableData" style="width: 100%">
        <el-table-column label="员工编号" prop="employeeId" />
      <el-table-column label="员工所属单位编号" prop="unitId" />
      <el-table-column label="员工姓名" prop="employeeName" />
      <el-table-column label="职位" prop="position" />
      <el-table-column label="残疾类型" prop="disabilityType" />
        <!-- ...其他表格列... -->
        <el-table-column align="right">
          <template #default="scope">
            
            <el-button
              size="small"
              type="primary"
              @click="handleApprove(scope.row)"
              v-if="scope.row.isApproval === 0"
            >审核通过</el-button>
            <el-button
              size="small"
              type="danger"
              @click="handleReject(scope.row)"
              v-if="scope.row.isApproval === 0"
            >审核拒绝</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </template>
  
  <script lang="ts" setup>
  import { computed, ref, onMounted } from 'vue';
  import axios from 'axios';
  
  interface User {
    employeeId: number,
    unitId: number,
    employeeName: string,
    position: string,
    disabilityType: string,
    isApproval: string,
  }
  
  const selectedSearchType = ref<string>('');
  const searchText = ref<string>('');
  const rawData = ref<User[]>([]);
  const filterTableData = ref<User[]>([]); 
    const handleSearch = () => {
    if (selectedSearchType.value && searchText.value) {
        filterTableData.value = rawData.value.filter((item) => {
        const searchValue = searchText.value.toLowerCase();
        const propValue = (item as any)[selectedSearchType.value]
          .toString()
          .toLowerCase();
        return propValue.includes(searchValue);
      });
    } else {
        filterTableData.value = rawData.value;
    }
  };
  const edituser = ref<User>({
    employeeId: 0,
    unitId: 0,
    employeeName: '',
    position: '',
    disabilityType: '',
    isApproval: '',
    });
    const edituser2 = ref<User>({
    employeeId: 0,
    unitId: 0,
    employeeName: '',
    position: '',
    disabilityType: '',
    isApproval: '',
    });
  
  const fetchData = async () => {
    try {
        const response = await axios.get('/api/unit-employee/list');
        rawData.value = response.data.data;
        filterTableData.value = rawData.value;
      } catch (error) {
        console.error('Fetch error:', error);
      }
  };
  
  onMounted(() => {
    fetchData();
  });
  
 
  
  const handleApprove = async (row: User) => {
  try {
    edituser.value.employeeId = row.employeeId; // 设置编辑用户的员工ID
    edituser.value.unitId = row.unitId;
    edituser.value.employeeName = row.employeeName;
    edituser.value.position = row.position;
    edituser.value.disabilityType = row.disabilityType;
    edituser.value.isApproval =  "1";
    const response = await axios.post(`/api/unit-employee/edit`, edituser.value);
    console.log('Approve response:', response.data);
    fetchData();
  } catch (error) {
    console.error('Approve error:', error);
  }
};
  
  const handleReject = async (row: User) => {
    try {
    edituser2.value.employeeId = row.employeeId; // 设置编辑用户的员工ID
    edituser2.value.unitId = row.unitId;
    edituser2.value.employeeName = row.employeeName;
    edituser2.value.position = row.position;
    edituser2.value.disabilityType = row.disabilityType;
    edituser2.value.isApproval = "2";
      const response = await axios.post(`/api/unit-employee/edit`,edituser2.value );
      console.log('Reject response:', response.data);
      fetchData();
    } catch (error) {
      console.error('Reject error:', error);
    }
  };
  </script>

  
  
  
  
  
  