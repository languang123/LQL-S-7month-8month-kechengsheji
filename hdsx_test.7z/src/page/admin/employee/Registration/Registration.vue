<template>
  <h1>单位职工登记</h1>
  <div>
    <pre>
      <el-input v-model="employeeData.employeeId" placeholder="员工编号" style="width: 300px;"></el-input>
      <el-input v-model="employeeData.unitId" placeholder="部门编号" style="width: 300px;"></el-input>
      <el-input v-model="employeeData.employeeName" placeholder="姓名" style="width: 300px;"></el-input>
      <el-input v-model="employeeData.position" placeholder="部门" style="width: 300px;"></el-input>
      <el-input v-model="employeeData.disabilityType" placeholder="残疾类型" style="width: 300px;"></el-input>
      <el-button size="large" type="primary" @click="addEmployee" round>添加</el-button>
    </pre>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import { ElInput, ElButton } from 'element-plus';

interface EmployeeData {
  employeeId: string;
  unitId: string;
  employeeName: string;
  position: string;
  disabilityType: string;
  isApproval: string;
}

export default defineComponent({
  components: {
    ElInput,
    ElButton,
  },
  data() {
    return {
      employeeData: {
        employeeId: '',
        unitId: '',
        employeeName: '',
        position: '',
        disabilityType: '',
        isApproval: '0',
      } as EmployeeData,
    };
  },
  methods: {
    async addEmployee() {
      try {
        const response = await fetch('/api/unit-employee/add', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(this.$data.employeeData), // 使用 this.$data
        });

        if (response.ok) {
          console.log('员工添加成功！');
          this.resetForm();
        } else {
          console.error('添加员工失败');
        }
      } catch (error) {
        console.error('网络请求失败', error);
      }
    },
    resetForm() {
      this.$data.employeeData = {
        employeeId: '',
        unitId: '',
        employeeName: '',
        position: '',
        disabilityType: '',
        isApproval: '0',
      };
    },
  },
});
</script>

<style>
/* 样式 */
</style>
