<template>
    <div>
      <h1>减、免、缓交保障金管理</h1>
      <div>
        <el-select v-model="selectedSearchType" placeholder="Select search type">
          <el-option label="减免/缓交编号" value="reductionWaiverId" />
          <el-option label="所属单位的编号" value="unitId" />
          <el-option label="减免/缓交原因" value="reductionReason" />
          <el-option label="减免/缓交金额" value="reductionAmount" />
          <el-option label="减免/缓交日期" value="reductionData" />
          <!-- 添加其他搜索类型的选项 -->
        </el-select>
        <el-input v-model="searchText" placeholder="Type to search" style="width: 200px" />
        <el-button size="small" @click="handleSearch">Search</el-button>
      </div>
      <el-table :data="filteredData" style="width: 100%">
        <el-table-column label="减免/缓交编号" prop="reductionWaiverId" />
        <el-table-column label="所属单位的编号" prop="unitId" />
        <el-table-column label="减免/缓交原因" prop="reductionReason" />
        <el-table-column label="减免/缓交金额" prop="reductionAmount" />
        <el-table-column label="减免/缓交日期" prop="reductionData" />
        <el-table-column align="align">
          <template #header>
          
          </template>
          <template #default="scope">
            <!-- <el-button size="small" @click="handleEdit(scope.$index, scope.row)">Edit</el-button> -->
            <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">Delete</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </template>
  
  <script lang="ts" setup>
  import { ref, onMounted } from 'vue';
  import axios from 'axios';
  
  interface ReduDefeInfo {
    reductionWaiverId: number;
    unitId: string;
    reductionReason: string;
    reductionAmount: number;
    reductionData: Date;
    
  }
  
  const selectedSearchType = ref<string>('');
  const searchText = ref<string>('');
  
  const rawData = ref<ReduDefeInfo[]>([]);
  const filteredData = ref<ReduDefeInfo[]>([]);
  
  const fetchData = async () => {
    try {
      const response = await axios.get('/api/reduction-waiver/list');
      rawData.value = response.data.data;
      filteredData.value = rawData.value;
    } catch (error) {
      console.error('Fetch error:', error);
    }
  };
  
  onMounted(() => {
    fetchData();
  });
  
  const handleSearch = () => {
    if (selectedSearchType.value && searchText.value) {
      filteredData.value = rawData.value.filter((item) => {
        const searchValue = searchText.value.toLowerCase();
        const propValue = (item as any)[selectedSearchType.value]
          .toString()
          .toLowerCase();
        return propValue.includes(searchValue);
      });
    } else {
      filteredData.value = rawData.value;
    }
  };
  
  
  
  const handleDelete = async (index: number, row: ReduDefeInfo) => {
    console.log(index, row);
  
    try {
      const response = await axios.delete(`/api/reduction-waiver/delete/${row.reductionWaiverId}`);
      console.log('Delete response:', response.data.data);
      fetchData();
    } catch (error) {
      console.error('Delete error:', error);
    }
  };
  
  </script>
  