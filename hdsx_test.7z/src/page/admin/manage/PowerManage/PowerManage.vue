<template>
    权限管理<br>
<!-- 表单1 -->
    <el-table :data="filterTableData" style="width: 100%">
    <el-table-column label="rId" prop="rid" />
    <el-table-column label="rName" prop="rname" />
    <el-table-column label="rDescription" prop="rescription" />
    <el-table-column align="right">
      <template #header>
        <el-input v-model="search" size="small" placeholder="Type to search" />
      </template>
      <template #default="scope">
        <el-button size="small" @click="handleEdit(scope.$index, scope.row)"
          >Edit</el-button
        >
        <el-button
          size="small"
          type="danger"
          @click="handleDelete(scope.$index, scope.row)"
          >Delete</el-button
        >
      </template>
    </el-table-column>
  </el-table><br>

<!-- 按钮1 -->
<el-button type="success">添加新权限</el-button>
<!-- 表单2 -->
<el-table :data="filterTableData2" style="width: 100%">
    <el-table-column label="cId" prop="cid" />
    <el-table-column label="cName" prop="cname" />
    <el-table-column label="cDescription" prop="cdescription" />
    <el-table-column align="right">
      <template #header>
        <el-input v-model="search" size="small" placeholder="Type to search" />
      </template>
      <template #default="scope">
        <el-button size="small" @click="handleEdit2(scope.$index, scope.row)"
          >Edit</el-button
        >
        <el-button
          size="small"
          type="danger"
          @click="handleDelete2(scope.$index, scope.row)"
          >Delete</el-button
        >
      </template>
    </el-table-column>
  </el-table><br>

<!-- 按钮2 -->
<el-button type="success">添加新角色</el-button>

   </template>

   <script lang="ts" setup >
   
import { computed, ref } from 'vue'

interface Role {
  rid: string
  rname: string
  rdescription: string
}

interface Chara {
  cid: string
  cname: string
  cdescription: string
}

const search = ref('')
const filterTableData = computed(() =>
  tableData.filter(
    (data) =>
      !search.value ||
      data.rname.toLowerCase().includes(search.value.toLowerCase())
  )
)
const handleEdit = (index: number, row: Role) => {
  console.log(index, row)
}
const handleDelete = (index: number, row: Role) => {
  console.log(index, row)
}


const search2 = ref('')
const filterTableData2 = computed(() =>
  tableData2.filter(
    (data) =>
      !search.value ||
      data.cname.toLowerCase().includes(search2.value.toLowerCase())
  )
)
const handleEdit2 = (index: number, row: Role) => {
  console.log(index, row)
}
const handleDelete2 = (index: number, row: Role) => {
  console.log(index, row)
}


import {
  Check,
  Delete,
  Edit,
  Message,
  Search,
  Star,
} from '@element-plus/icons-vue'
   </script>

   <style scoped lang="scss">
   
   </style>