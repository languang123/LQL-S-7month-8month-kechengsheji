<template>
    <div>
      <h1>统计报表</h1>
      <div>
        <el-select v-model="selectedSearchType" placeholder="Select search type">
          <el-option label="单位编号" value="unitId" />
          <el-option label="单位名称" value="paymentDate" />
          <el-option label="单位地址" value="paymentAmount" />
          <el-option label="单位联系人" value="paymentMethod" />
          <el-option label="单位联系电话" value="contactPhone" />
          <!-- 添加其他搜索类型的选项 -->
        </el-select>
        <el-input v-model="searchText" placeholder="Type to search" style="width: 200px" />
        <el-button size="small" @click="handleSearch">Search</el-button>
    </div>
    <el-table :data="filteredData" style="width: 100%">
        <el-table-column label="单位编号" prop="unitId" />
        <el-table-column label="单位编号" prop="typeId" />
        <el-table-column label="单位名称" prop="unitName" />
        <el-table-column label="单位地址" prop="unitAddress" />
        <el-table-column label="单位联系人" prop="contactPerson" />
        <el-table-column label="单位联系电话" prop="contactPhone" />
    </el-table>
</div>
</template>
  
<script lang="ts" setup>
import { computed, ref, onMounted } from 'vue';
import axios from 'axios';

interface User {
    unitId: string,
    typeId: string,
    unitName: string,
    unitAddress: string,
    contactPerson: string,
    contactPhone: string,
}

const selectedSearchType = ref<string>('');
  const searchText = ref<string>('');
  
  const rawData = ref<User[]>([]);
  const filteredData = ref<User[]>([]);

const fetchData = async () => {
    try {
      const response = await axios.get('/api/unit-profile/list');
      rawData.value = response.data.data;
      filteredData.value = rawData.value;
    } catch (error) {
      console.error('Fetch error:', error);
    }
  };


onMounted(() => {
    fetchData(); // 在组件挂载时调用 fetchData 函数来获取数据
});
const handleSearch = () => {
    if (selectedSearchType.value && searchText.value) {
      filteredData.value = rawData.value.filter((item) => {
        const searchValue = searchText.value.toLowerCase();
        const propValue = (item as any)[selectedSearchType.value]
          .toString()
          .toLowerCase();
        return propValue.includes(searchValue);
      });
    } else {
      filteredData.value = rawData.value;
    }
  };



const handleDelete = async (index: number, row: User) => {
    console.log(index, row);

    try {
        const response = await axios.delete(`/api/unit-profile/delete/${row.unitId}`);
        console.log('Delete response:', response.data.data);
        // 在这里你可以根据后端返回的数据进行相应的处理
        fetchData(); // 删除数据后重新获取数据更新表格
    } catch (error) {
        console.error('Delete error:', error);
    }
};
</script>
  