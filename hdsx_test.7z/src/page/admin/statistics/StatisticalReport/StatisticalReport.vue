<template>
    统计报表
   </template>
   <script lang="ts" setup >
   
   </script>
   <style scoped lang="scss">
   
   </style>