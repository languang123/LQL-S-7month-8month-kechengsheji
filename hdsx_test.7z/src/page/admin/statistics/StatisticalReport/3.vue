<template>
    <div>
      <h1>单位保障金缴纳信息管理</h1>
      <div>
        <el-select v-model="selectedSearchType" placeholder="Select search type">
          <el-option label="缴纳编号" value="paymentId" />
          <el-option label="所属单位的编号" value="unitId" />
          <el-option label="缴纳日期" value="paymentDate" />
          <el-option label="缴纳金额" value="paymentAmount" />
          <el-option label="缴纳方式" value="paymentMethod" />
          <!-- 添加其他搜索类型的选项 -->
        </el-select>
        <el-input v-model="searchText" placeholder="Type to search" style="width: 200px" />
        <el-button size="small" @click="handleSearch">Search</el-button>
      </div>
      <el-table :data="filteredData" style="width: 100%">
        <el-table-column label="缴纳编号" prop="paymentId" />
        <el-table-column label="所属单位的编号" prop="unitId" />
        <el-table-column label="缴纳日期" prop="paymentDate" />
        <el-table-column label="缴纳金额" prop="paymentAmount" />
        <el-table-column label="缴纳方式" prop="paymentMethod" />
        <el-table-column label="缴纳状态" prop="paymentStatus" />
        <el-table-column align="center">
          
        </el-table-column>
      </el-table>
    </div>
  </template>
  
  <script lang="ts" setup>
  import { ref, onMounted } from 'vue';
  import axios from 'axios';
  
  interface Payment {
    paymentId: number;
    unitId: number;
    paymentDate: Date;
    paymentAmount: number;
    paymentMethod: string;
    paymentStatus: string;
  }
  
  const selectedSearchType = ref<string>(''); // Default to "缴纳状态"
  const searchText = ref<string>('');
  const rawData = ref<Payment[]>([]);
  const filteredData = ref<Payment[]>([]);
  
  const fetchData = async () => {
    try {
      const response = await axios.get('/api/insurance-payment/list');
      rawData.value = response.data.data;
      filterDataByPaymentStatus(); // Filter initially based on default search type
    } catch (error) {
      console.error('Fetch error:', error);
    }
  };
  
  onMounted(() => {
    fetchData();
  });
  
  const handleSearch = () => {
    filterDataByPaymentStatus();
  };
  
  const filterDataByPaymentStatus = () => {
    filteredData.value = rawData.value.filter(item => {
      return item.paymentStatus === '0';
    });
  };
  
  const handleDelete = async (index: number, row: Payment) => {
    console.log(index, row);
  
    try {
      const response = await axios.post(`/api/insurance-payment/delete/${row.paymentId}`);
      console.log('Delete response:', response.data);
      fetchData();
    } catch (error) {
      console.error('Delete error:', error);
    }
  };
  
  </script>
  