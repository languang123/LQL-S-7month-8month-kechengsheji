<template>
    <div>
        <h1>单位人员信息统计报表</h1>
        <div>
          <el-select v-model="selectedSearchType" placeholder="Select search type">
            <el-option label="减免/缓交编号" value="reductionWaiverId" />
            <el-option label="所属单位的编号" value="unitId" />
            <el-option label="减免/缓交原因" value="reductionReason" />
            <el-option label="减免/缓交金额" value="reductionAmount" />
            <el-option label="减免/缓交日期" value="reductionData" />
            <!-- 添加其他搜索类型的选项 -->
          </el-select>
          <el-input v-model="searchText" placeholder="Type to search" style="width: 200px" />
          <el-button size="small" @click="handleSearch">Search</el-button>
        </div>
      <el-table :data="filterTableData" style="width: 100%">
        
        <el-table-column label="员工编号" prop="employeeId" />
        <el-table-column label="员工所属单位编号" prop="unitId" />
        <el-table-column label="员工姓名" prop="employeeName" />
        <el-table-column label="职位" prop="position" />
        <el-table-column label="残疾类型" prop="disabilityType" />
        <el-table-column label="审核状态" prop="isApproval" />
        <el-table-column align="right">
          
         
        </el-table-column>
      </el-table>
    </div>
    </template>
    
    <script lang="ts" setup>
    import { computed, ref, onMounted } from 'vue';
  import axios from 'axios';
  
  interface User {
      employeeId: number,
      unitId: number,
      employeeName: string,
      position: string,
      disabilityType: string,
      isApproval: number,
  }
  
  const selectedSearchType = ref<string>('');
    const searchText = ref<string>('');
    
    const rawData = ref<User[]>([]);
    const filterTableData = ref<User[]>([]);
  
    const fetchData = async () => {
      try {
        const response = await axios.get('/api/unit-employee/list');
        rawData.value = response.data.data;
        filterTableData.value = rawData.value;
      } catch (error) {
        console.error('Fetch error:', error);
      }
    };
  
  onMounted(() => {
    fetchData(); // 在组件挂载时调用 fetchData 函数来获取数据
  });
  
  const handleSearch = () => {
      if (selectedSearchType.value && searchText.value) {
        filterTableData.value = rawData.value.filter((item) => {
          const searchValue = searchText.value.toLowerCase();
          const propValue = (item as any)[selectedSearchType.value]
            .toString()
            .toLowerCase();
          return propValue.includes(searchValue);
        });
      } else {
        filterTableData.value = rawData.value;
      }
    };
  
  
  
  const handleDelete = async (index: number, row: User) => {
    console.log(index, row);
  
    try {
      const response = await axios.delete(`/api/unit-employee/${row.employeeId}`);
      console.log('Delete response:', response.data);
      // 在这里你可以根据后端返回的数据进行相应的处理
      fetchData(); // 删除数据后重新获取数据更新表格
    } catch (error) {
      console.error('Delete error:', error);
    }
  };
    </script>
    