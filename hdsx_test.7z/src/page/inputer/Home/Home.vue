<template>
    <div>
        Welcome to the home page!
    </div>
</template>
   <script lang="ts" setup >
   
   </script>
   <style scoped lang="scss">
   
   </style>


