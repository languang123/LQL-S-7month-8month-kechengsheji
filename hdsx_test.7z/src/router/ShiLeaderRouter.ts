import ShiLeaderLayout from '@/layout/ShiLeaderLayout.vue'
const ShiLeaderRouter =  // 市领导端
{
  path:'/page/shileader',
  component : ShiLeaderLayout,
  children:[
    {
      path:'',
      name:'home',
      component:()=>import('@/page/admin/Home/Home.vue')  
    },
    {
      path:'/user',
      name:'用户管理',
      component:()=>import('@/page/admin/UserManage/UserManage.vue')
    }
  ]
}
export default ShiLeaderRouter