import AdminLayout from '@/layout/AppLayout.vue';
import { RouterView } from 'vue-router'
const AdminRouter =  // 管理员端
{
  path: '/page/admin',
  component: AdminLayout,
  children: [
    {
      path: '/',
      name: 'home',
      component: () => import('@/page/admin/Home/Home.vue'),
      meta: { title: '首页', icon: '<el-icon><UserFilled /></el-icon>' },
    },
    {
      path: '/archive',
      name: '单位档案管理',
      component: RouterView,
      children: [
        {
          path: 'BasicInfo',
          name: '单位基本信息管理',
          component: () => import('@/page/admin/archive/BasicInfo/BasicInfo.vue'),
        },
        {
          path: 'PersInfo',
          name: '单位人员信息管理',
          component: () => import('@/page/admin/archive/PersInfo/PersInfo.vue'),
        },
        {
          path: 'PaymentInfo',
          name: '单位保障金缴纳信息管理',
          component: () => import('@/page/admin/archive/PaymentInfo/PaymentInfo.vue'),
        },
        {
          path: 'ReduDefeInfo',
          name: '减、免、缓交保障金管理',
          component: () => import('@/page/admin/archive/ReduDefeInfo/ReduDefeInfo.vue'),
        },
      ]
    },
    {
      path: '/employee',
      name: '单位职工审核',
      component: RouterView,
      meta: { title: '职工审核', icon: '<el-icon><UserFilled /></el-icon>' },
      children: [

        {
          path: 'Registration',
          name: '单位职工登记',
          component: () => import('@/page/admin/employee/Registration/Registration.vue'),
        },
        {
          path: 'DisabilityReview',
          name: '单位残疾人职工审核',
          component: () => import('@/page/admin/employee/DisabilityReview/DisabilityReview.vue'),
        },
      ]
    },
    {
      path: '/InsuranceSupervision',
      name: '保障金征收及使用监管',
      component: RouterView,
      children: [

        {
          path: 'LevySupervision',
          name: '保障金征收监管',
          component: () => import('@/page/admin/InsuranceSupervision/LevySupervision/LevySupervision.vue'),
        },
        {
          path: 'UseSupervision',
          name: '保障金使用监管',
          component: () => import('@/page/admin/InsuranceSupervision/UseSupervision/UseSupervision.vue'),
        }
      ]
    },
    {
      path: '/Summary',
      name: '统计报表',
      component: RouterView,
      children: [

        {
          path: 'UnitInfomation',
          name: '单位档案表',
          component: () => import('@/page/admin/statistics/StatisticalReport/1.vue'),
        },
        {
          path: 'Sunmaryfordisabler',
          name: '单位残疾人统计',
          component: () => import('@/page/admin/statistics/StatisticalReport/2.vue'),
        },
        {
          path: 'Summarforunpid',
          name: '未缴纳单位统计',
          component: () => import('@/page/admin/statistics/StatisticalReport/3.vue'),
        },
        {
          path: 'Summaryforpid',
          name: '已缴纳单位统计',
          component: () => import('@/page/admin/statistics/StatisticalReport/4.vue'),
        },
        // {
        //   path: 'Summaryforother',
        //   name: '减、免、缓交保障金统计',
        //   component: () => import('@/page/admin/Summary/Summaryforother.vue'),
        // },
        {
          path: 'StatisticReport',
          name: '统计报表',
          component: () => import('@/page/admin/statistics/StatisticalReport/StatisticalReport.vue'),
        }
      ]

    },
    {
      path: '/print',
      name: '打印',
      component: RouterView,
      children: [

        {
          path: 'Notice',
          name: '缴款通知书打印',
          component: () => import('@/page/admin/print/Notice/Notice.vue'),
        },
        {
          path: 'WrittenDecision',
          name: '征收决定书打印',
          component: () => import('@/page/admin/print/WrittenDecision/WrittenDecision.vue'),
        }

      ]

    },
    {
      path: '/manage',
      name: '系统管理',
      component: RouterView,
      children: [
        {
          path: 'UserManage',
          name: '用户管理',
          component: () => import('@/page/admin/manage/UserManage/UserManage.vue'),
        },
        {
          path: 'PowerManage',
          name: '权限管理',
          component: () => import('@/page/admin/manage/PowerManage/PowerManage.vue'),
        },
        {
          path: 'BackupRecovery',
          name: '系统备份和恢复',
          component: () => import('@/page/admin/manage/BackupRecovery/BackupRecovery.vue'),
        }
      ]
    }

  ]
}
export default AdminRouter