import XianLeaderLayout from '@/layout/XianLeaderLayout.vue'
const XianLeaderRouter =  // 县领导端
{
  path:'/page/xianleader',
  component : XianLeaderLayout,
  children:[
    {
      path:'',
      name:'home',
      component:()=>import('@/page/admin/Home/Home.vue')  
    },
    {
      path:'/user',
      name:'用户管理',
      component:()=>import('@/page/admin/UserManage/UserManage.vue')
    }
  ]
}
export default XianLeaderRouter