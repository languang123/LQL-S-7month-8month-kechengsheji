import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router'
import manageRouter from './manageRouter'
import AdminRouter from './AdminRouter'
/**
 * 1. 因为我们分了客户端和管理端两部分，只有管理端需要有Layout导航 所以如下router管理分开了。
 * 2. 引用组建时，这里后缀要带上vue 因为ts知道默认找.vue文件
 * 
 */

const routes: RouteRecordRaw[] = [
  // 管理端
  //manageRouter,
  // 管理员端
  AdminRouter,
  //clientRouter,

]

const router = createRouter({
  // 路由模式
  history: createWebHistory(),
  routes,
})

export default router