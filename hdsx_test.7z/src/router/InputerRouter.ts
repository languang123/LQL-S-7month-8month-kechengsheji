import InputerLayout from '@/layout/InputerLayout.vue'
const InputerRouter =  // 数据录入员端
{
  path:'/page/inputer',
  component : InputerLayout,
  children:[
    {
      path:'',
      name:'home',
      component:()=>import('@/page/admin/Home/Home.vue')  
    },
    {
      path:'/user',
      name:'用户管理',
      component:()=>import('@/page/admin/UserManage/UserManage.vue')
    }
  ]
}
export default InputerRouter