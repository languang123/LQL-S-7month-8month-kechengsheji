import { createApp } from 'vue';
import App from './App.vue';
import router from './router/Router'; // 引入Vue Router配置
import store from './store'; // 引入Vuex配置
import Login from './views/Login.vue'; // 引入Login组件
// ElementPlus 和 其 css文件
import ElementPlus from 'element-plus';
import 'element-plus/dist/index.css';
import * as ElIcons from '@element-plus/icons-vue'

const app = createApp(App)
for (const name in ElIcons){
    app.component(name,(ElIcons as any)[name])
}

// 注册Vue Router
app.use(router);

// 注册Vuex
app.use(store);
app.use(ElementPlus);

app.mount('#app');
